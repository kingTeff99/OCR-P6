
// LA BARRE DE MENU
/**
 * SI on clique sur un élément du menu
 * ALORS On est redirectionné vers son url
 * exemple : SI je clique sur profile, ALORS j'obtiens les infos de la personne
 * SI je clique sur home ou transfer, ALORS je demeure sur le menu principal 
 * SI je clique sur log off, ALORS je quitte l'application
 * 
 */

$(document).ready(function () {

    $("#profile").click(function () {
        $.ajax
        ({
            type: 'GET',
            url: 'http://localhost:8080/users/1/infos',
            dataType: 'jsonp',
            async: false,
         })
    });

    var response = {
        "id": 1,
        "firstName": "Hayley",
        "lastName": "Dupont",
        "username": "hayleydupont@gmail.com"
    }

    $("#contact").click(function () {
        $.ajax
        ({
            type: 'GET',
            url: 'http://localhost:8080/users/1/contact',
            dataType: 'jsonp',
            async: false,
         })
    });

    var response1 = [
        {
            "id": 1,
            "userRelatingId": {
                "id": 2,
                "firstName": "Clara",
                "lastName": "Kata",
                "username": "clarakata@gmail.com"
            },
            "userRelatedId": {
                "id": 1,
                "firstName": "Hayley",
                "lastName": "Dupont",
                "username": "hayleydupont@gmail.com"
            }
        },
        {
            "id": 3,
            "userRelatingId": {
                "id": 3,
                "firstName": "Smith",
                "lastName": "Wesson",
                "username": "smithwesson@gmail.com"
            },
            "userRelatedId": 1
        }
    ]
});

// ADD CONNEXION
/**
 * SI Je clique dessus  
 * ALORS Je dois POST l'url suivant : http://localhost:8080/api/contact/add
 * et POST Les data avec le format suivant : x-www-form-urlencoded
 * ET les key suivantes : {'username': , 'myUsername': }
 */

 $(document).ready(function () {

    $("#add_connexion").click(function () {
        $.ajax
        ({
            type: 'POST',
            url: 'http://localhost:8080/contact/add',
            dataType: 'jsonp',
            data: {"username": "smithwesson@gmail.com" ,
             "myUsername" : "clarakata@gmail.com" },
            async: false,
         })
    });

    var response2 = {
        "id": 6,
        "userRelatedId": 3,
        "userRelatingId": 2
    };

});

// SEND MONEY (formulaire)
/**
 * Je remplis le formulaire et récupère les infos sur 
 * le montant et le contact
 * et Je CLIQUE Sur PAY et 
 * on remplit le json suivant de cet URL: 
 * http://localhost:8080/api/transaction/make
 * 
 * 
 */

$(document).ready(function() {

    $(".login1").submit(function () {
        var name = $("#connex").val();
        var amount = $("#money").val();
        transaction(name, amount);
    });

    var response3 = {
        "id": 4,
        "amount": 100.0,
        "description": "Buy a fragrance "
    };
});

function transaction(name, amount) {

    $.ajax 
    ({
            type: "POST",
            url: 'http://localhost:8080/transaction/make',
            dataType: 'jsonp',
            async: false,
            data: {
                "id": null,
                "amount": amount,
                "userSenderId": 1,
                "userReceiverId": 2,
                "bankSenderId": 1,
                "bankReceiverId": 2,
                "fees": null,
                "description": "Buy a fragrance "
            },
            success: function (data) {
                alert('Login status: ' + data.status);
            }
         })
    };

