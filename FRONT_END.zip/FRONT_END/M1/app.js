// Entrer Les Infos (username, password)
// Soumettre à l'aide du button Login
// Donc Recuperer Ses Infos dans le JQuery pour se connecter
// 

// ( function ($) {


//     $('#login1').on('click', function(e){
//         e.preventDefault();
//         var $input = $(this);
//         var url = 'http://localhost:8080/api/users';
//         $.ajax({

//             url,
//             crossDomain: true,
//             type: 'GET',
//             // dataType: 'json',
//             headers: {  'Access-Control-Allow-Origin': 'http://localhost:5500'},
//             success: function(jqxhr) { alert("Success"); },
//             error: function(jqxhr) { alert('Failed!'); },
            
//         });

//         // $.ajaxSetup({
//         //     beforeSend: function(xhr) {
//         //         xhr.setRequestHeader('Access-Control-Allow-Origin', '*');
//         //     }
//         // });

//     });
    
// })(jQuery);



$(document).ready(function() {

    $(".login1").submit(function () {
        var email = $("#email1").val();
        var password1 = $("#password1").val();
        authenticate(email, password1);
    });
});

    function authenticate(email, password1) {

        $.ajax
        ({
            type: "POST",
            url: 'http://localhost:8080/api/login',
            dataType: 'jsonp',
            async: false,
            data: {'email': email, 'password1': password1},
            success: function (data) {
                alert('Login status: ' + data.status);
            }
         })
    };